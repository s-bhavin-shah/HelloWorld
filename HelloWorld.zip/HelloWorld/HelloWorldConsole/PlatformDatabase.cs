﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorldConsole
{
    public class PlatformDatabase : Platform
    {
        public override void WriteMessage(string Message)
        {
            throw new NotImplementedException();
        }
    }
}
